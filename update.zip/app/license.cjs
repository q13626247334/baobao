"use strict";
/**
 * 授权校验（离线算法，无需联网，一码一机绑定）
 * 与番茄小说定时上传助手的授权码完全通用（同一个母钥匙和算法）：
 *   授权码格式：BB-<8位hex盐>-<4位天数补零>-[<昵称hex水印>-]<摘要前8位大写>
 *   摘要内容绑定对方电脑机器码，码转给第二台电脑立即失效。
 */
const crypto = require("crypto");
const fs = require("fs");
const os = require("os");
const path = require("path");
const { execSync } = require("child_process");

const LICENSE_MASTER = "bbao-7f3a9c51-e2d84b06"; // 母钥匙（与旧版生成器相同）
const LICENSE_DIR = path.join(os.homedir(), "包包AI写作助手数据");
const LICENSE_FILE = path.join(LICENSE_DIR, "license.key");

function getMachineCode() {
  let guid = "";
  try {
    const out = execSync(
      'reg query "HKLM\\SOFTWARE\\Microsoft\\Cryptography" /v MachineGuid',
      { encoding: "utf8", stdio: ["pipe", "pipe", "pipe"] });
    const m = out.match(/MachineGuid\s+REG_SZ\s+([^\r\n]+)/);
    if (m) guid = m[1].trim();
  } catch (e) { /* 读不到注册表就走备用指纹 */ }
  if (!guid) {
    // 第二优先：主板 UUID（csproduct），跟网络设备完全无关——翻墙/加速器的 TUN 虚拟网卡
    // 时有时无，MAC 兜底会漂移导致授权反复失效；主板 UUID 重装系统都不变，最稳。
    try {
      let out = '';
      try {
        out = execSync('wmic csproduct get uuid', { encoding: 'utf8', stdio: ['pipe', 'pipe', 'pipe'] });
      } catch (e1) {
        // 新版 Win11 可能没有 wmic，改走 CIM 查询
        out = execSync('powershell.exe -NoProfile -Command (Get-CimInstance Win32_ComputerSystemProduct).UUID',
          { encoding: 'utf8', stdio: ['pipe', 'pipe', 'pipe'] });
      }
      const mu = String(out).match(/([0-9A-Fa-f]{8}-[0-9A-Fa-f]{4}-[0-9A-Fa-f]{4}-[0-9A-Fa-f]{4}-[0-9A-Fa-f]{12})/);
      if (mu && !/^0+-0+-0+-0+-0+$/.test(mu[1])) guid = 'MB-' + mu[1].toUpperCase();
    } catch (e) { /* 读不到主板 UUID 就继续走 MAC 兜底 */ }
  }
  if (!guid) {
    // 最后兜底：物理网卡 MAC。过滤虚拟网卡（虚拟机/部分热点）。
    // 注意：加速器 TUN 网卡 MAC 常是随机值且不在已知虚拟 OUI 名单里，所以这只是第三选择。
    const VIRTUAL_OUI = /^(00:05:69|00:0c:29|00:50:56|08:00:27|00:15:5d|00:ff|52:54:00|33:50:6f)/i;
    const all = [];
    const nets = os.networkInterfaces();
    for (const name of Object.keys(nets)) {
      for (const n of nets[name] || []) {
        if (!n.internal && n.mac && n.mac !== "00:00:00:00:00:00") all.push(n.mac);
      }
    }
    const physical = all.filter((mac) => !VIRTUAL_OUI.test(mac));
    guid = (physical.length ? physical : all).sort().join("|") || os.hostname() || "UNKNOWN";
  }
  const h = crypto.createHash("sha256").update(guid, "utf8").digest("hex").toUpperCase();
  const code = `${h.slice(0, 4)}-${h.slice(4, 8)}-${h.slice(8, 12)}`;
  rememberMachineCode(code);
  return code;
}

// ---------- 本机历史机器码记忆 ----------
// 某些系统（装机版/GHOST）读不到注册表 MachineGuid，兜底 MAC 列表会随网络设备变化，
// 导致机器码漂移、授权反复失效。把本机出现过的机器码全部记住（带电脑名防整份拷贝白嫖），
// 校验时当前码或任一历史码匹配都算通过——已经发出去的授权永久有效。
const CODES_FILE = path.join(LICENSE_DIR, "machine_codes.json");
function knownMachineCodes() {
  try {
    const arr = JSON.parse(fs.readFileSync(CODES_FILE, "utf8"));
    return Array.isArray(arr) ? arr : [];
  } catch (e) { return []; }
}
function rememberMachineCode(code) {
  try {
    const host = os.hostname();
    const list = knownMachineCodes().filter((e) => e && typeof e === "object" && e.code);
    if (!list.some((e) => e.code === code && e.host === host)) {
      list.push({ code, host, at: Date.now() });
      fs.mkdirSync(LICENSE_DIR, { recursive: true });
      fs.writeFileSync(CODES_FILE, JSON.stringify(list.slice(-30)), "utf8");
    }
  } catch (e) { /* 记不住也不影响本次校验 */ }
}
function machineCodesForVerify() {
  const host = os.hostname();
  const all = [normMachine(getMachineCode())];
  for (const e of knownMachineCodes()) {
    if (!e || !e.code) continue;
    if (e.host && e.host !== host) continue; // 数据被拷到别的电脑：电脑名对不上，不认
    all.push(normMachine(e.code));
  }
  return [...new Set(all)];
}

function normMachine(code) {
  return (code || "").replace(/-/g, "").trim().toUpperCase();
}

function digest(payload) {
  return crypto.createHash("sha256")
    .update(LICENSE_MASTER + "|" + payload + "|", "utf8").digest("hex");
}

function payload(salt, days, nameHex, machine) {
  return [salt, String(days).padStart(4, "0"), nameHex, machine]
    .filter(Boolean).join("|");
}

// 生成授权码（生成器网页同款算法；days=0 表示永久）
function makeLicenseCode(days, name, machine, salt) {
  salt = (salt || crypto.randomBytes(8).toString("hex").slice(0, 8)).toUpperCase();
  days = Math.max(0, Math.min(9999, parseInt(days, 10) || 0));
  const nameHex = Buffer.from((name || "").trim(), "utf8").toString("hex").toUpperCase();
  const mac = normMachine(machine);
  const tail = digest(payload(salt, days, nameHex, mac)).slice(0, 8).toUpperCase();
  const mid = nameHex ? "-" + nameHex : "";
  return `BB-${salt}-${String(days).padStart(4, "0")}${mid}-${tail}`;
}

function verifyLicenseCode(code) {
  try {
    const parts = code.trim().toUpperCase().split("-");
    let salt, daysS, nameHex = "", tail;
    if (parts.length === 4) [, salt, daysS, tail] = parts;
    else if (parts.length === 5) [, salt, daysS, nameHex, tail] = parts;
    else return null;
    if (!salt || (nameHex && nameHex.length % 2)) return null;
    const name = nameHex ? Buffer.from(nameHex, "hex").toString("utf8") : "";
    const days = parseInt(daysS, 10);
    if (!(days >= 0 && days <= 9999)) return null;
    const hit = machineCodesForVerify().some((mc) =>
      digest(payload(salt, days, nameHex, mc)).slice(0, 8).toUpperCase() === tail);
    if (!hit) return null;
    return { days, name };
  } catch (e) { return null; }
}

// 返回 {ok, name, days, expired?}
function checkLicense() {
  try {
    const lines = fs.readFileSync(LICENSE_FILE, "utf8")
      .split(/\r?\n/).map((s) => s.trim()).filter(Boolean);
    if (lines.length >= 2) {
      const ret = verifyLicenseCode(lines[0]) || verifyLicenseCodeV2(lines[0]);
      if (!ret) return { ok: false };
      if (ret.days === 0) return { ok: true, name: ret.name, days: ret.days, v1: !ret.v2 };
      const activated = parseFloat(lines[1]) * 1000; // 存的是秒
      // 锚点取「本机激活时间」和「签发时间」里较晚的：本机时间被回拨也不能白嫖延长
      const anchor = Math.max(activated, (ret.issuedAt || 0) * 1000);
      // 本机时间回拨到锚点一周之前 = 明显改表，直接判过期（ dated 授权才查，永久授权不吃这套 ）
      if (Date.now() < anchor - 7 * 86400000) return { ok: false, expired: true };
      if (Date.now() - anchor < ret.days * 86400000) {
        return { ok: true, name: ret.name, days: ret.days, v1: !ret.v2 };
      }
      return { ok: false, expired: true };
    }
  } catch (e) { /* 没文件就当未激活 */ }
  return { ok: false };
}

function activate(code) {
  const ret = verifyLicenseCode(code) || verifyLicenseCodeV2(code);
  if (!ret) return { ok: false };
  fs.mkdirSync(LICENSE_DIR, { recursive: true });
  fs.writeFileSync(LICENSE_FILE, code.trim() + "\n" + String(Math.floor(Date.now() / 1000)) + "\n", "utf8");
  try {
    // 激活成功即上报登记（fire-and-forget，失败不影响激活）：
    // 包包后台「💻软件授权码」列表立刻可见，随时可停用（停用后下次启动在线校验拦截）
    let mc = ""; try { mc = getMachineCode(); } catch (e) {}
    httpPostJson(REGISTER_PATH, { code: code.trim(), machine: mc }, 5000);
  } catch (e) {}
  return { ok: true, name: ret.name, days: ret.days };
}

// ================= 新格式 v2：Ed25519 服务端签名（3.1.0 起） =================
// 旧 v1 是「母钥匙对称校验」，钥匙在客户端字节码里，会被逆向提取后自己造码。
// v2 改成非对称签名：客户端只带公钥，能验不能签；私钥只在包包的生成器里。
// 格式：BB2-<base64url(payloadJSON)>.<base64url(64字节签名)>
const V2_PUBLIC_B64 = "bGD5Hu1FXGdiZRkxTbBWI52LNFEevo9fRvoOVwjU6ps="; // 只验签，公开无妨
let _v2pub = null;
function v2pub() {
  if (!_v2pub) {
    _v2pub = crypto.createPublicKey({
      key: Buffer.concat([Buffer.from("302a300506032b6570032100", "hex"), Buffer.from(V2_PUBLIC_B64, "base64")]),
      format: "der", type: "spki",
    });
  }
  return _v2pub;
}
const b64urlToBuf = (s) => Buffer.from(String(s).replace(/-/g, "+").replace(/_/g, "/") + "===".slice((String(s).length + 3) % 4), "base64");

function verifyLicenseCodeV2(code) {
  try {
    const s = code.trim();
    if (!/^BB2-[A-Za-z0-9_-]+\.[A-Za-z0-9_-]{20,}$/.test(s)) return null;
    const body = s.slice(4);
    const dot = body.indexOf(".");
    const payloadB64 = body.slice(0, dot), sigB64 = body.slice(dot + 1);
    const sig = b64urlToBuf(sigB64);
    if (sig.length !== 64) return null;
    // 签名盖在 payload 的 base64url 字符串上（生成器签的就是这串）
    if (!crypto.verify(null, Buffer.from(payloadB64, "utf8"), v2pub(), sig)) return null;
    const j = JSON.parse(b64urlToBuf(payloadB64).toString("utf8"));
    if (!j || j.v !== 2 || typeof j.m !== "string") return null;
    const days = parseInt(j.d, 10);
    if (!(days >= 0 && days <= 9999)) return null;
    const mc = normMachine(j.m);
    if (!/^[0-9A-F]{12}$/.test(mc)) return null;
    if (!machineCodesForVerify().includes(mc)) return null; // 不是本机的码
    const name = typeof j.n === "string" ? j.n.slice(0, 32) : "";
    return { days, name, v2: true, issuedAt: parseInt(j.i, 10) || 0 };
  } catch (e) { return null; }
}

module.exports = { getMachineCode, makeLicenseCode, verifyLicenseCode, verifyLicenseCodeV2, checkLicense, activate };

// ---------- 远程停用名单 ----------
// 包包在管理端（bb-build/revoke.py）把滥用的授权码尾段加进 revoked.json，
// 文件放发布仓库（jsdelivr/GitHub 代理分发，和自动更新同一个通道）。
// 用户联网启动时核对：自己码的尾段在名单里 = 授权被停用，退回激活窗口。
// 拉不到名单时宽容处理（用 7 天内的本地缓存，缓存也没有就不查）——
// 停用是刹车不是路障，绝不让网络问题误伤正常用户。
// 只信实时回源的 gh-proxy 镜像：jsdelivr 等 CDN 会缓存旧名单好几天，
// 2026-10-10 真出过事——名单已清空但 jsdelivr 还挂着一周前的旧缓存，
// 把包包本机授权误停了。停用决策绝不能用可能陈旧的缓存做。
// 两个实时镜像都拉不到时宁可暂不停用（宽容处理），也不误伤正常用户。
const REPO = "q13626247334/baobao";
const REVOKE_MIRRORS = [
  "https://gh-proxy.com/https://raw.githubusercontent.com/" + REPO + "/main",
  "https://ghproxy.net/https://raw.githubusercontent.com/" + REPO + "/main",
];
const REVOKE_CACHE = path.join(LICENSE_DIR, "revoked_cache.json"); // 仅供留档，停用决策不读它

function storedLicenseTail() {
  try {
    const line = (fs.readFileSync(LICENSE_FILE, "utf8").split(/\r?\n/)[0] || "").trim().toUpperCase();
    if (line.startsWith("BB2-")) return line.slice(4); // v2 用整段 payload.sig 当停用标识
    const seg = line.split("-");
    return seg.length >= 2 ? seg[seg.length - 1] : "";
  } catch (e) { return ""; }
}

// ---------- 在线校验（3.2.0 起）：包包自己的服务器为第一通道 ----------
// 网站后台点「停用」→ 本机软件下次启动直接退回激活窗口，秒生效不靠 GitHub 镜像。
// 宽容原则与老机制一致：只有服务器明确返回"已停用"才算停用；
// 服务器拉不到（断网/翻墙/服务器维护）→ 退回 GitHub 停用名单老通道 → 也不可用就放行。
// 停用是刹车不是路障，绝不让网络问题误伤正常用户。
const CHECK_HOST = "baobao-prompts.app.workbuddy.host";
const CHECK_PATH = "/api/dl/check?sharecode=3JQ5XUMYMS";
const REGISTER_PATH = "/api/dl/register?sharecode=3JQ5XUMYMS";

function storedLicenseCode() {
  try { return (fs.readFileSync(LICENSE_FILE, "utf8").split(/\r?\n/)[0] || "").trim(); } catch (e) { return ""; }
}

function httpPostJson(urlPath, obj, timeoutMs) {
  return new Promise((resolve) => {
    let settled = false;
    const done = (v) => { if (!settled) { settled = true; resolve(v); } };
    try {
      const payload = Buffer.from(JSON.stringify(obj), "utf8");
      const req = require("https").request({
        hostname: CHECK_HOST, path: urlPath, method: "POST", family: 4, timeout: timeoutMs,
        headers: { "Content-Type": "application/json", "Content-Length": payload.length, "User-Agent": "baobao-license" },
      }, (res) => {
        if (res.statusCode !== 200) { res.resume(); return done(null); }
        let data = ""; res.setEncoding("utf8");
        res.on("data", (c) => { data += c; });
        res.on("end", () => { try { done(JSON.parse(data)); } catch (e) { done(null); } });
      });
      req.on("timeout", () => { try { req.destroy(); } catch (e) {} done(null); });
      req.on("error", () => done(null));
      req.write(payload); req.end();
    } catch (e) { done(null); }
  });
}

function httpGetText(url, timeoutMs, redirects) {
  return new Promise((resolve) => {
    redirects = redirects || 0;
    let settled = false;
    const done = (v) => { if (!settled) { settled = true; resolve(v); } };
    try {
      const mod = String(url).startsWith("http://") ? require("http") : require("https");
      const req = mod.get(url, { family: 4, timeout: timeoutMs, headers: { "User-Agent": "baobao-license", "Cache-Control": "no-cache" } }, (res) => {
        if (res.statusCode >= 300 && res.statusCode < 400 && res.headers.location && redirects < 5) {
          res.resume();
          const next = /^https?:\/\//.test(res.headers.location) ? res.headers.location : new URL(res.headers.location, url).href;
          httpGetText(next, timeoutMs, redirects + 1).then(done);
          return;
        }
        if (res.statusCode !== 200) { res.resume(); return done(null); }
        let data = "";
        res.setEncoding("utf8");
        res.on("data", (c) => { data += c; });
        res.on("end", () => done(data));
      });
      req.on("timeout", () => { try { req.destroy(); } catch (e) {} done(null); });
      req.on("error", () => done(null));
    } catch (e) { done(null); }
  });
}

async function loadRevokedList(timeoutMs) {
  const per = Math.max(2000, Math.floor((timeoutMs || 8000) / REVOKE_MIRRORS.length));
  for (const base of REVOKE_MIRRORS) {
    // 缓存戳：gh-proxy 这类代理会按完整 URL 缓存，带上时间戳参数强制回源取最新名单，
    // 停用/恢复操作才能即时生效（2026-10-10 事故教训：代理缓存的旧名单误伤正常用户）
    const txt = await httpGetText(base + "/revoked.json?ts=" + Date.now(), per);
    if (!txt) continue;
    try {
      const j = JSON.parse(txt);
      if (!Array.isArray(j.codes)) continue;
      const codes = j.codes.map((s) => String(s).toUpperCase().trim()).filter(Boolean);
      try {
        fs.mkdirSync(LICENSE_DIR, { recursive: true });
        fs.writeFileSync(REVOKE_CACHE, JSON.stringify({ at: Date.now(), codes }), "utf8");
      } catch (e) {}
      return codes;
    } catch (e) { /* 内容坏了换下一个镜像 */ }
  }
  // 10-10 事故加固：本地缓存绝不做停用决定——jsdelivr 等 CDN 可能缓存陈旧名单，
  // 一旦回退到旧缓存就会误停正常付费用户。宁可在断网时暂不停用，也不误伤。
  // （上面仍会写缓存留档，但这里绝不读它。）
  return null; // null = 查不了（断网太久），调用方按"未停用"放行
}

// true=已被远程停用；false=正常；断网/超时一律 false（不误伤）
async function checkRevoked(timeoutMs) {
  const full = storedLicenseCode();
  if (!full) return false;
  // 第一通道：包包自己的服务器（网站后台点停用 → 实时权威答案）
  const t1 = Math.max(3000, Math.floor((timeoutMs || 8000) / 2));
  const srv = await httpPostJson(CHECK_PATH, { code: full }, t1);
  if (srv && typeof srv.ok !== "undefined") {
    // 服务器在线：它的回答就是权威（未登记的码服务端也回 ok，宽容放行）
    return srv.ok === 0 && srv.ban ? true : false;
  }
  // 第二通道：服务器拉不到 → GitHub 停用名单老机制
  const tail = storedLicenseTail();
  if (!tail) return false;
  const codes = await loadRevokedList(timeoutMs);
  if (!codes) return false;
  return codes.includes(tail);
}

// 执行停用：license.key 挪走留证（.revoked），软件回到未激活窗口
function applyRevocation() {
  try {
    if (fs.existsSync(LICENSE_FILE)) {
      const bak = LICENSE_FILE + ".revoked";
      fs.rmSync(bak, { force: true });
      fs.renameSync(LICENSE_FILE, bak);
    }
  } catch (e) {}
}

module.exports.checkRevoked = checkRevoked;
module.exports.applyRevocation = applyRevocation;
