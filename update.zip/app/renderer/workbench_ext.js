/* ============================================================
   首页工作台外挂（明文，不参与混淆）
   功能：① 工作台页（今日发文/字数/投稿/下载 + 投稿漏斗全宽 + 账号概况）
        ② 左侧边栏导航（顶部页签挪到左边 + 左下角账号一行汇总）
        ③ 默认打开即工作台（wb-boot 遮罩防闪屏）
   历史：榜单速览因番茄接口链路不稳定已按用户拍板移除（2026-11-01）
   原则：全部 try/catch，出错绝不影响软件原有功能
   ============================================================ */
(function () {
  'use strict';
  if (window.__wbLoaded) return; window.__wbLoaded = true;

  /* ---------- 小工具 ---------- */
  function today() { var d = new Date(); return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0'); }
  function LSget(k, d) { try { var v = localStorage.getItem(k); return v ? JSON.parse(v) : d; } catch (e) { return d; } }
  function LSset(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch (e) {} }
  function esc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }

  var bb = window.baobao || {};
  function fqCmd(o) { try { bb.fanqieCmd && bb.fanqieCmd(o); } catch (e) {} }

  /* ---------- 状态 ---------- */
  var cal = LSget('wb_cal', {});              // 档案 -> 每日统计 {日期:{chapters,chars}}
  var profiles = LSget('wb_profiles', {});    // 档案 -> {lastOk,lastErr}
  var dlStats = LSget('wb_dl', {});           // 日期 -> 下载数
  var tgStats = LSget('wb_tg', {});           // 日期 -> 投稿数
  var dirtyAcct = false, lastCalPull = 0;

  /* ---------- 事件监听（叠加注册，不影响 app.js 自己的监听） ---------- */
  try {
    bb.onFanqieEvent && bb.onFanqieEvent(function (e) {
      try {
        if (!e || typeof e !== 'object') return;
        var p = e.profile || null;
        if (p && !profiles[p]) { profiles[p] = {}; dirtyAcct = true; }
        if (p && e.ok === true) { profiles[p].lastOk = Date.now(); dirtyAcct = true; }
        if (p && e.ok === false) { profiles[p].lastErr = Date.now(); dirtyAcct = true; }
        if (e.op === 'calendar') { cal[e.profile || '默认'] = e.data || {}; LSset('wb_cal', cal); renderStats(); }
        if (e.op === 'data_books' && e.ok && p) { pullCalendar(); }
        var op = String(e.op || '');
        if (op.indexOf('dl') === 0 && (e.ok === true || /完成|成功/.test(String(e.msg || e.message || '')))) bumpDl();
      } catch (e2) {}
    });
  } catch (e) {}
  try {
    bb.onLog && bb.onLog(function (_, msg) {
      try {
        var s = String(msg || '');
        if (/第\s*\d+\s*章.{0,14}(完成|成功)|发文成功|发布成功/.test(s)) okToast('发文成功，继续冲 ✍️');
        else if (/投稿.{0,6}(成功|完成|已发送)|✅.{0,8}投递/.test(s)) { bumpTg(); okToast('投稿已发出 ✈️'); }
        else if (/下载(完成|成功)|已保存到|下载完毕/.test(s)) { bumpDl(); okToast('下载完成 📖'); }
      } catch (e2) {}
    });
  } catch (e) {}

  /* ---------- 成功反馈 toast（绿勾） ---------- */
  var lastToast = 0;
  function okToast(txt) {
    try {
      var now = Date.now(); if (now - lastToast < 1500) return; lastToast = now;
      var host = document.getElementById('wbToasts');
      if (!host) { host = document.createElement('div'); host.id = 'wbToasts'; document.body.appendChild(host); }
      var t = document.createElement('div');
      t.className = 'wb-oktoast';
      t.innerHTML = '<span class="wb-okcheck">✓</span>' + esc(txt);
      host.appendChild(t);
      setTimeout(function () { t.classList.add('out'); setTimeout(function () { try { t.remove(); } catch (e) {} }, 450); }, 2600);
    } catch (e) {}
  }

  function bumpDl() { var t = today(); dlStats[t] = (dlStats[t] || 0) + 1; LSset('wb_dl', dlStats); renderStats(); }
  function bumpTg() { var t = today(); tgStats[t] = (tgStats[t] || 0) + 1; LSset('wb_tg', tgStats); renderStats(); }

  /* ---------- 💌 投稿漏斗 ---------- */
  function renderFunnel() {
    try {
      var box = document.getElementById('wbFunnel');
      if (!box) return;
      if (!window.tgx || !window.tgx.invoke) { box.innerHTML = '<div class="wb-rank-msg gray">当前版本暂无投稿数据接口</div>'; return; }
      window.tgx.invoke('tg:ext:report').then(function (r) {
        try {
          var s = (r && r.sent) || {};
          var total = (Number(s.ok) || 0) + (Number(s.fail) || 0);
          if (!r || !r.ok || !total) { box.innerHTML = '<div class="wb-rank-msg gray">还没有投稿记录，去「💌 投稿」发出第一封就有了</div>'; return; }
          var maxv = Math.max(total, Number(s.ok) || 0);
          var rows = [
            { lab: '📨 投稿发送', val: total, sub: '' },
            { lab: '✅ 发送成功', val: Number(s.ok) || 0, sub: Math.round((Number(s.ok) || 0) * 100 / total) + '%' },
            { lab: '⚠️ 退信/失败', val: Number(s.fail) || 0, sub: Math.round((Number(s.fail) || 0) * 100 / total) + '%' }
          ];
          box.innerHTML = rows.map(function (x) {
            var w = Math.max(4, Math.round((x.val || 0) * 100 / maxv));
            return '<div class="wb-frow"><span class="wb-flab">' + x.lab + '</span><div class="wb-fbar"><i style="width:' + w + '%"></i></div><span class="wb-fval">' + x.val + (x.sub ? ' <em>' + x.sub + '</em>' : '') + '</span></div>';
          }).join('') +
            '<div class="wb-feditors">📚 编辑库 ' + (r.total || 0) + ' 位 · 当前收稿 ' + ((r.status && (r.status['当前'] || 0)) || 0) + ' 位 · 退信原因归类见「💌 投稿」页体检报告</div>';
        } catch (e2) { box.innerHTML = '<div class="wb-rank-msg gray">数据解析失败</div>'; }
      }).catch(function () {
        box.innerHTML = '<div class="wb-rank-msg gray">还没有投稿记录，去「💌 投稿」发出第一封就有了</div>';
      });
    } catch (e) {}
  }

  /* ---------- 发文统计：向引擎要 calendar ---------- */
  function pullCalendar() {
    var now = Date.now();
    if (now - lastCalPull < 30000) return; lastCalPull = now;
    Object.keys(profiles).forEach(function (p) { fqCmd({ cmd: 'calendar', profile: p }); });
    if (!Object.keys(profiles).length) fqCmd({ cmd: 'calendar', profile: '默认' });
  }

  /* ---------- UI 构建 ---------- */
  function build() {
    try {
      var nav = document.querySelector('nav.tabs');
      if (nav && !document.getElementById('tabWork')) {
        var b = document.createElement('button');
        b.className = 'tab'; b.id = 'tabWork'; b.textContent = '🏠 工作台';
        nav.insertBefore(b, nav.firstChild);
        b.onclick = function () { window.switchTab('Work'); };
        var acct = document.createElement('div');
        acct.id = 'wbAcct'; acct.title = '点击进入番茄发文页管理账号';
        acct.onclick = function () { window.switchTab('Fanqie'); };
        nav.appendChild(acct);
        // ❓ 帮助入口：右上角问号迁入侧边栏底部（各页共用一个入口，点它=看当前页的帮助）
        if (!document.getElementById('wbHelp')) {
          var hb = document.createElement('button');
          hb.type = 'button'; hb.id = 'wbHelp'; hb.textContent = '❓ 帮助';
          hb.title = '这页怎么用？';
          hb.onclick = function () {
            try {
              var views = document.querySelectorAll('div[id^=view]');
              var cur = null;
              for (var i = 0; i < views.length; i++) {
                if (views[i].style.display !== 'none') { cur = views[i]; break; }
              }
              var btn = cur && cur.querySelector('.help-btn');
              if (!btn) btn = document.querySelector('#viewWrite .help-btn');
              if (btn) btn.click();
            } catch (e) {}
          };
          nav.insertBefore(hb, acct);
        }
        // 账号概况悬停弹窗（鼠标移到侧边栏账号行就弹出，不用点）
        var pop = document.createElement('div');
        pop.id = 'wbAcctPop';
        pop.innerHTML = '<div class="wb-pop-title">👤 账号概况</div>'
          + '<div id="wbAcctLine" class="wb-acctline">读取中…</div>'
          + '<div id="wbAcctList" class="wb-acctlist"></div>'
          + '<div class="wb-hint">绿点=最近正常；橙点=最近一次引擎回报异常（可能要重新扫码）。不发任何网络请求。</div>';
        document.body.appendChild(pop);
        var hideTimer = null;
        var showPop = function () { clearTimeout(hideTimer); pop.classList.add('on'); };
        var hidePop = function () { clearTimeout(hideTimer); hideTimer = setTimeout(function () { pop.classList.remove('on'); }, 200); };
        acct.addEventListener('mouseenter', showPop);
        acct.addEventListener('mouseleave', hidePop);
        pop.addEventListener('mouseenter', showPop);
        pop.addEventListener('mouseleave', hidePop);
        // 🌸 包包写作天地品牌块（从顶部横幅迁入，保留原按钮的点击事件）
        var btnH = document.getElementById('btnHeaven');
        if (btnH && !document.getElementById('wbBrand')) {
          var brand = document.createElement('div');
          brand.id = 'wbBrand';
          brand.innerHTML = '<div class="wb-brand-sub">写小说 · 找灵感 · 许愿都在这里 ✨</div>'
            + '<div class="wb-brand-links">官网更新</div>';
          brand.insertBefore(btnH, brand.firstChild);
          nav.insertBefore(brand, document.getElementById('tabWork'));
          var hb = document.querySelector('.heaven-bar');
          if (hb) hb.style.display = 'none';
          // 兜底：万一 app.js 的绑定没生效，自己绑（重复绑定 onclick 属性只会覆盖不会叠加，安全）
          setTimeout(function () {
            try {
              if (btnH && !btnH.onclick) btnH.onclick = function () { bb.openUrl && bb.openUrl('https://baobao-prompts.app.workbuddy.host/?sharecode=3JQ5XUMYMS'); };
            } catch (e) {}
          }, 800);
        }
        // 🌙 明暗切换已并入页脚「界面配色」下拉（夜间模式重复，删掉侧边栏入口）
      }
      if (!document.getElementById('viewWork')) {
        var vw = document.createElement('div');
        vw.id = 'viewWork'; vw.style.display = 'none';
        vw.innerHTML =
          '<header class="topbar">' +
          '  <div class="logo"><span class="baozi"></span></div>' +
          '  <div class="titles"><h1>今日工作台</h1><p>打开软件先看一眼：写了多少、投稿漏斗健康吗</p></div>' +
          '  <div class="status-pill"><span class="dot"></span><span id="wbDate">' + today() + '</span></div>' +
          '</header>' +
          '<main class="grid wb-grid">' +
          '  <section class="card wb-cards">' +
          '    <div class="wb-stat"><div class="wb-num" id="wbCh">0</div><div class="wb-lab">📝 今日发文（章）</div></div>' +
          '    <div class="wb-stat"><div class="wb-num" id="wbChars">0</div><div class="wb-lab">✍️ 今日字数</div></div>' +
          '    <div class="wb-stat"><div class="wb-num" id="wbTg">0</div><div class="wb-lab">📨 今日投稿（封）</div></div>' +
          '    <div class="wb-stat"><div class="wb-num" id="wbDl">0</div><div class="wb-lab">⬇️ 今日下载（本）</div></div>' +
          '  </section>' +
          '  <div class="wb-duo">' +
          '  <section class="card wb-funnelcard">' +
          '    <div class="wb-rank-head"><h3>💌 投稿漏斗</h3><button type="button" class="btn mini" id="wbFunnelGo">去投稿</button></div>' +
          '    <div id="wbFunnel" class="wb-funnel"><div class="wb-rank-msg gray">读取中…</div></div>' +
          '    <div class="wb-hint">数据来自「💌 投稿」页的发送记录与编辑库，随投稿自动累积。账号概况把鼠标移到左下角「账号」一行就能看。</div>' +
          '  </section>' +
          '  <section class="card wb-pulsecard">' +
          '    <div class="wb-rank-head"><h3>🔥 连续发文 · 本周对比</h3></div>' +
          '    <div id="wbPulse" class="wb-pulse"><div class="wb-rank-msg gray">读取中…</div></div>' +
          '  </section>' +
          '  </div>' +
          '</main>';
        var first = document.getElementById('viewWrite');
        first.parentNode.insertBefore(vw, first);
        var fg = document.getElementById('wbFunnelGo');
        if (fg) fg.onclick = function () { window.switchTab('Tougao'); };
      }
    } catch (e) {}
  }

  /* ---------- 渲染 ---------- */
  function renderStats() {
    try {
      var t = today(), ch = 0, chars = 0;
      Object.keys(cal).forEach(function (p) {
        var d = cal[p] && cal[p][t];
        if (d) { ch += Number(d.chapters) || 0; chars += Number(d.chars) || 0; }
      });
      var el;
      (el = document.getElementById('wbCh')) && (el.textContent = ch);
      (el = document.getElementById('wbChars')) && (el.textContent = chars >= 10000 ? (chars / 10000).toFixed(1) + ' 万' : chars);
      (el = document.getElementById('wbTg')) && (el.textContent = tgStats[t] || 0);
      (el = document.getElementById('wbDl')) && (el.textContent = dlStats[t] || 0);
    } catch (e) {}
    renderAcct();
    renderPulse();
  }

  /* ---------- 🔥 连续发文 · 本周对比 ---------- */
  function dayStr(d) { return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0'); }
  function dailySum(key, field) { var t = 0; Object.keys(cal).forEach(function (p) { var d = cal[p] && cal[p][key]; if (d) t += Number(d[field]) || 0; }); return t; }
  function mondayOf(d) { var x = new Date(d); x.setHours(0, 0, 0, 0); var w = x.getDay(); if (w === 0) w = 7; x.setDate(x.getDate() - (w - 1)); return x; }
  function renderPulse() {
    var el = document.getElementById('wbPulse'); if (!el) return;
    try {
      var now = new Date(), t = dayStr(now);
      var streak = 0, cur = new Date(now);
      if (dailySum(dayStr(cur), 'chapters') <= 0) cur.setDate(cur.getDate() - 1);
      while (dailySum(dayStr(cur), 'chapters') > 0) { streak++; cur.setDate(cur.getDate() - 1); }
      var mon = mondayOf(now), mon2 = new Date(mon); mon2.setDate(mon2.getDate() - 7);
      var dayIdx = Math.floor((new Date(now.getFullYear(), now.getMonth(), now.getDate()) - mon) / 86400000) + 1; // 周一=1
      var wkC = 0, wkChars = 0, lwC = 0, lwChars = 0, i, d, k;
      for (i = 0; i < dayIdx; i++) {
        d = new Date(mon); d.setDate(d.getDate() + i); k = dayStr(d);
        wkC += dailySum(k, 'chapters'); wkChars += dailySum(k, 'chars');
        d = new Date(mon2); d.setDate(d.getDate() + i); k = dayStr(d);
        lwC += dailySum(k, 'chapters'); lwChars += dailySum(k, 'chars');
      }
      var diff = wkC - lwC;
      var diffTxt = diff > 0 ? '↑ 比上周同期多 ' + diff + ' 章' : (diff < 0 ? '↓ 比上周同期少 ' + (-diff) + ' 章' : '和上周同期持平');
      var diffCls = diff > 0 ? '#1d9e75' : (diff < 0 ? '#c26a3c' : '#888780');
      var h = '';
      h += '<div style="font-size:15px;font-weight:700;margin:2px 0 8px">' + (streak > 0 ? '🔥 连续发文 ' + streak + ' 天' : '今天还没发文——开个头？') + '</div>';
      h += '<div style="font-size:12.5px;color:#888780;margin:3px 0">本周发文 <b style="color:#5F5E5A">' + wkC + '</b> 章 · ' + Number(wkChars).toLocaleString() + ' 字</div>';
      h += '<div style="font-size:12.5px;color:#888780;margin:3px 0">上周同期 <b style="color:#5F5E5A">' + lwC + '</b> 章 · <b style="color:' + diffCls + '">' + diffTxt + '</b></div>';
      el.innerHTML = h;
    } catch (e) { el.innerHTML = '<div class="wb-rank-msg gray">统计暂时读不到</div>'; }
  }

  function acctState() {
    var names = Object.keys(profiles), bad = [];
    names.forEach(function (p) {
      var s = profiles[p] || {};
      if (s.lastErr && (!s.lastOk || s.lastErr > s.lastOk)) bad.push(p);
    });
    return { names: names, bad: bad };
  }

  function renderAcct() {
    try {
      var st = acctState(), n = st.names.length, line, cls;
      if (!n) { line = '暂未发现账号档案，去「🍅 番茄发文」用一次就有了'; cls = 'gray'; }
      else if (!st.bad.length) { line = '🟢 番茄账号 ' + n + ' 个 · 全部正常'; cls = 'ok'; }
      else { line = '🟠 番茄账号 ' + n + ' 个 · ' + st.bad.length + ' 个需要重新扫码'; cls = 'warn'; }
      var el = document.getElementById('wbAcctLine');
      if (el) { el.textContent = line; el.className = 'wb-acctline ' + cls; }
      var side = document.getElementById('wbAcct');
      if (side) { side.textContent = line; side.className = 'wb-side-acct ' + cls; }
      var list = document.getElementById('wbAcctList');
      if (list) {
        list.innerHTML = st.names.map(function (p) {
          var s = profiles[p] || {};
          var bad = s.lastErr && (!s.lastOk || s.lastErr > s.lastOk);
          var when = s.lastOk ? new Date(s.lastOk).toLocaleString('zh-CN', { month: 'numeric', day: 'numeric', hour: '2-digit', minute: '2-digit' }) : '—';
          return '<div class="wb-acctrow"><span class="wb-dot ' + (bad ? 'bad' : 'good') + '"></span>' + esc(p) + '<span class="wb-when">' + (bad ? '最近异常' : '最近正常 ' + when) + '</span></div>';
        }).join('') || '<div class="wb-acctrow gray">第一次用「🍅 番茄发文」后，这里会显示每个账号的状态</div>';
      }
    } catch (e) {}
  }

  /* ---------- 接管 switchTab：Work 页显隐 + 进入时刷新 ---------- */
  function wrapSwitch() {
    if (typeof window.switchTab !== 'function' || window.__wbSwitched) { if (!window.__wbSwitched) setTimeout(wrapSwitch, 300); return; }
    window.__wbSwitched = true;
    var orig = window.switchTab;
    window.switchTab = function (name) {
      try { orig.apply(this, arguments); } catch (e) {}
      try { document.documentElement.classList.remove('wb-boot'); } catch (e) {}
      try {
        var vw = document.getElementById('viewWork');
        if (vw) vw.style.display = (name === 'Work') ? '' : 'none';
        var tb = document.getElementById('tabWork');
        if (tb) tb.classList.toggle('active', name === 'Work');
        if (name === 'Work') { renderStats(); renderFunnel(); pullCalendar(); }
      } catch (e) {}
    };
  }

  /* ---------- 任务横幅不遮字：横幅出现时把整个界面往下推（包包 11-01 反馈抓榜单时大标题被横幅挡住） ---------- */
  function watchTaskBanner() {
    var tb = document.getElementById('taskBanner');
    if (!tb) { setTimeout(watchTaskBanner, 300); return; }
    var last = null;
    var sync = function () {
      var on = false;
      try { on = getComputedStyle(tb).display !== 'none' && tb.offsetHeight > 0; } catch (e) {}
      if (on === last) return;
      last = on;
      try {
        if (on) { document.body.style.paddingTop = tb.offsetHeight + 'px'; }
        else { document.body.style.paddingTop = ''; }
      } catch (e) {}
    };
    sync();
    new MutationObserver(sync).observe(tb, { attributes: true, attributeFilter: ['style', 'class'] });
    window.addEventListener('resize', sync);
  }

  /* ---------- 启动 ---------- */
  function start() {
    build();
    watchTaskBanner();
    try { localStorage.removeItem('wb_rank_1'); localStorage.removeItem('wb_rank_2'); localStorage.removeItem('wb_gender'); } catch (e) {} // 清理已下线榜单的旧缓存
    wrapSwitch();
    renderStats(); renderAcct(); renderFunnel(); renderPulse();
    // 默认打开就是工作台：能切就立刻切（同一帧内完成，不闪屏）；切不动再退避重试
    var go = function () {
      try {
        if (typeof window.switchTab !== 'function') { setTimeout(go, 200); return; }
        window.switchTab('Work');
      } catch (e) {}
    };
    go();
    setTimeout(function () {
      try { if (document.getElementById('viewWork') && document.getElementById('viewWork').style.display === 'none') window.switchTab('Work'); } catch (e) {}
    }, 800);
    // 默认进入工作台后立刻拉一次数据
    setTimeout(function () { try { pullCalendar(); } catch (e) {} }, 1500);
    setInterval(function () { try { if (dirtyAcct) { dirtyAcct = false; LSset('wb_profiles', profiles); } renderAcct(); } catch (e) {} }, 5000);
  }
  if (document.readyState === 'complete' || document.readyState === 'interactive') start();
  else document.addEventListener('DOMContentLoaded', start);
})();
