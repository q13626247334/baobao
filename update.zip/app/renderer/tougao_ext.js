/* 包包投稿扩展 · 渲染层（明文，不参与混淆）
 * 依赖 window.tgx.invoke（preload 注入，仅放行 tg:ext:*）。
 * 注入：编辑库体检 / 失败原因诊断 / 投稿打卡 / 日志自动滚到最新（收起清空按钮已按用户要求移除）。
 * （作品档案、群发预览已按包包要求于 2026-11-01 撤下，新建投稿保持旧版界面）
 * 全部防御式注入，找不到锚点就静默跳过，不影响原界面。
 */
(function () {
  'use strict';
  if (!window.tgx) return;
  const $ = id => document.getElementById(id);
  const esc = s => String(s == null ? '' : s).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
  const call = (ch, p) => window.tgx.invoke(ch, p || {});

  /* ---------- 独立弹窗 ---------- */
  let XDLG = null;
  function xdlg(title, html, btns) {
    if (!XDLG) {
      XDLG = document.createElement('div');
      XDLG.style.cssText = 'position:fixed;inset:0;background:rgba(40,20,30,.45);z-index:99999;display:none;align-items:center;justify-content:center';
      XDLG.addEventListener('click', e => { if (e.target === XDLG) XDLG.style.display = 'none'; });
      document.body.appendChild(XDLG);
    }
    XDLG.innerHTML = '<div style="background:#fff;border-radius:16px;max-width:680px;width:92%;max-height:82vh;overflow:auto;padding:22px 24px;box-shadow:0 18px 60px rgba(0,0,0,.25)">'
      + '<h3 style="margin:0 0 12px;font-size:17px;color:#c2497e">' + esc(title) + '</h3>'
      + '<div style="font-size:13.5px;line-height:1.9;color:#4a3542">' + html + '</div>'
      + '<div style="text-align:right;margin-top:16px">' + (btns || '<button class="btn" onclick="this.closest(\'div[style*=fixed]\').style.display=\'none\'">关闭</button>') + '</div></div>';
    XDLG.style.display = 'flex';
  }
  function copyTxt(t) {
    try { navigator.clipboard.writeText(t); } catch (e) {
      const ta = document.createElement('textarea'); ta.value = t; document.body.appendChild(ta); ta.select();
      try { document.execCommand('copy'); } catch (_) {} ta.remove();
    }
  }

  /* ---------- 作品档案 / 群发预览 ---------- */
  // 2026-11-01 包包拍板：新建投稿恢复旧版界面（只有选择文档 + 邮件主题 + 勾选编辑），
  // 作品档案大卡片和预览按钮全部撤下；主进程 tg:ext:profile:* 通道保留但界面不再调用。

  /* ---------- 编辑库体检 ---------- */
  async function healthReport() {
    const d = await call('tg:ext:report').catch(() => null);
    if (!d || !d.ok) { xdlg('🩺 编辑库体检', '读取失败，稍后再试'); return; }
    const bar = (label, n, total, color) => {
      const pct = total ? Math.round(n / total * 100) : 0;
      return '<div style="display:flex;align-items:center;gap:8px;margin:4px 0"><span style="width:72px;font-size:12.5px">' + label + '</span>'
        + '<div style="flex:1;height:14px;background:#f6e8ef;border-radius:8px;overflow:hidden"><div style="width:' + pct + '%;height:100%;background:' + color + '"></div></div>'
        + '<b style="font-size:12.5px;width:44px;text-align:right">' + n + '</b></div>';
    };
    const st = d.status || {};
    const colors = { '当前': '#e5538a', '投前确认': '#f0a24b', '待核实': '#b3a0ea', '待复核': '#b3a0ea', '历史': '#9aa0a6' };
    let h = '<div style="font-size:13px">共 <b>' + d.total + '</b> 位编辑 · 数据更新于 ' + esc(d.updatedAt || '—') + '</div>';
    h += '<div style="margin:10px 0">' + Object.keys(st).map(k => bar(k, st[k], d.total, colors[k] || '#7fc9a6')).join('') + '</div>';
    h += '<div style="background:#fff8fb;border-radius:12px;padding:12px 14px;margin-top:6px"><b>📮 发送体检</b><div style="margin-top:4px">成功 ' + d.sent.ok + ' · 失败 ' + d.sent.fail + '</div>';
    const b = d.sent.bounce || {};
    const bkeys = Object.keys(b).filter(k => b[k] > 0);
    h += bkeys.length ? bkeys.map(k => '<div style="font-size:12.5px;margin-top:3px">· ' + esc(k) + '：<b>' + b[k] + '</b> 次' + (d.sent.bounceSamples[k] ? ' <span style="color:#9b8290">例：' + esc(d.sent.bounceSamples[k]).slice(0, 60) + '</span>' : '') + '</div>').join('') : '<div style="font-size:12.5px;color:#9b8290">暂无失败记录</div>';
    h += '</div><div style="margin-top:10px"><b>💡 体检建议</b>' + (d.tips || []).map(t => '<div style="margin-top:5px;font-size:12.5px">· ' + esc(t) + '</div>').join('') + '</div>';
    if (d.dupList.length) h += '<div style="margin-top:8px;color:#b04a72;font-size:12.5px"><b>重复邮箱：</b>' + d.dupList.map(esc).join('；') + '</div>';
    xdlg('🩺 编辑库体检报告', h);
  }

  /* ---------- 投稿打卡分享卡片 ---------- */
  function rr(ctx, x, y, w, h, r) { // 圆角矩形路径
    ctx.beginPath();
    ctx.moveTo(x + r, y);
    ctx.arcTo(x + w, y, x + w, y + h, r); ctx.arcTo(x + w, y + h, x, y + h, r);
    ctx.arcTo(x, y + h, x, y, r); ctx.arcTo(x, y, x + w, y, r);
    ctx.closePath();
  }
  async function punchCard() {
    const d = await call('tg:ext:punch').catch(() => null);
    if (!d || !d.ok) { xdlg('📸 投稿打卡', '读取投稿数据失败，稍后再试'); return; }
    const orgN = 2; // 隐私保护：不渲染投递明细列表，固定占位高度
    const listTop = 820, trendTop = listTop + orgN * 44 + 30;
    const W = 900, H = trendTop + 310;
    const cv = document.createElement('canvas'); cv.width = W; cv.height = H;
    const ctx = cv.getContext('2d');
    const F = "'Microsoft YaHei','PingFang SC',sans-serif";
    // 底
    let g = ctx.createLinearGradient(0, 0, 0, H);
    g.addColorStop(0, '#fff7fb'); g.addColorStop(1, '#ffeaf3');
    ctx.fillStyle = g; ctx.fillRect(0, 0, W, H);
    // 顶部渐变横幅
    rr(ctx, 40, 40, W - 80, 200, 28);
    g = ctx.createLinearGradient(40, 40, W - 40, 240);
    g.addColorStop(0, '#f5a623'); g.addColorStop(1, '#ff6ea9');
    ctx.fillStyle = g; ctx.fill();
    ctx.fillStyle = '#fff'; ctx.textAlign = 'center';
    ctx.font = 'bold 56px ' + F; ctx.fillText('📮 投稿打卡', W / 2, 128);
    const wk = ['日', '一', '二', '三', '四', '五', '六'][new Date().getDay()];
    ctx.font = '26px ' + F; ctx.globalAlpha = .92;
    ctx.fillText(d.day.replace(/-/g, '.') + ' · 星期' + wk, W / 2, 180);
    ctx.globalAlpha = 1;
    // 今日大数字
    ctx.fillStyle = '#c2497e'; ctx.font = 'bold 34px ' + F;
    ctx.fillText('今 日 投 稿', W / 2, 330);
    ctx.font = 'bold 150px ' + F;
    g = ctx.createLinearGradient(W / 2 - 200, 340, W / 2 + 200, 480);
    g.addColorStop(0, '#f5a623'); g.addColorStop(1, '#ff6ea9');
    ctx.fillStyle = g; ctx.fillText(String(d.today.mails), W / 2, 470);
    ctx.fillStyle = '#8a6b7a'; ctx.font = '30px ' + F;
    ctx.fillText('封', W / 2, 520);
    // 三个小指标
    const cells = [
      ['覆盖平台', d.today.orgCount + ' 个', '#e5538a'],
      ['作品', d.today.docCount + ' 篇', '#8a5cf6'],
      ['连续打卡', d.streak + ' 天', '#f0954b']
    ];
    cells.forEach((c, i) => {
      const cx = 90 + i * ((W - 180) / 3), cw = (W - 180) / 3 - 24;
      rr(ctx, cx, 570, cw, 150, 20);
      ctx.fillStyle = '#fff'; ctx.shadowColor = 'rgba(214,79,126,.12)'; ctx.shadowBlur = 16; ctx.fill(); ctx.shadowBlur = 0;
      ctx.fillStyle = c[2]; ctx.font = 'bold 44px ' + F; ctx.fillText(c[1], cx + cw / 2, 645);
      ctx.fillStyle = '#9b8290'; ctx.font = '24px ' + F; ctx.fillText(c[0], cx + cw / 2, 690);
    });
    // 打卡人（隐私保护：不展示书名与投递明细，只展示昵称）
    ctx.textAlign = 'left';
    ctx.fillStyle = '#c2497e'; ctx.font = 'bold 30px ' + F;
    ctx.fillText('👤 今日打卡人', 90, 780);
    ctx.fillStyle = '#4a3542'; ctx.font = 'bold 46px ' + F;
    ctx.fillText(d.penName ? '「' + d.penName + '」' : '包包学员', 138, listTop + 28);
    ctx.fillStyle = '#9b8290'; ctx.font = '24px ' + F;
    ctx.fillText('投递平台 ' + d.today.orgCount + ' 个 · 投稿明细仅自己可见，作品隐私放心', 138, listTop + 82);
    // 近7天趋势
    ctx.fillStyle = '#c2497e'; ctx.font = 'bold 30px ' + F; ctx.fillText('📈 近 7 天', 90, trendTop + 10);
    const max = Math.max(1, ...d.trend.map(t => t.mails));
    d.trend.forEach((t, i) => {
      const bw = 66, x = 110 + i * 100, bh = Math.round((t.mails / max) * 110), y = trendTop + 180 - bh;
      ctx.fillStyle = t.mails ? '#ff8fb8' : '#f3dfe8';
      rr(ctx, x, y, bw, Math.max(bh, 8), 8); ctx.fill();
      ctx.fillStyle = '#9b8290'; ctx.font = '20px ' + F; ctx.textAlign = 'center';
      ctx.fillText(String(t.mails || ''), x + bw / 2, y - 10);
      ctx.fillText(t.day, x + bw / 2, trendTop + 205);
      ctx.textAlign = 'left';
    });
    // 底部署名
    ctx.textAlign = 'center';
    ctx.fillStyle = '#b08aa0'; ctx.font = '26px ' + F;
    ctx.fillText((d.penName ? '「' + d.penName + '」 · ' : '') + '累计 ' + d.totalMails + ' 封 · 包包AI写作助手', W / 2, H - 40);
    // 弹窗展示
    const url = cv.toDataURL('image/png');
    xdlg('📸 投稿打卡卡（保存后发到群里打卡）',
      '<div style="text-align:center"><img src="' + url + '" style="max-width:100%;max-height:52vh;border-radius:14px;box-shadow:0 8px 30px rgba(214,79,126,.2)"></div>',
      '<button class="btn pink" id="tgxPunchSave">💾 保存图片</button> <button class="btn" onclick="this.closest(\'div[style*=fixed]\').style.display=\'none\'">关闭</button>');
    const sb = document.getElementById('tgxPunchSave');
    if (sb) sb.onclick = async () => {
      const name = '投稿打卡_' + d.day + '.png';
      let okMsg = '';
      try {
        if (window.baobao && window.baobao.savePng) {
          const r = await window.baobao.savePng(url, name);
          okMsg = r && r.path ? '✓ 已保存：' + r.path : (r && r.canceled ? '' : '✓ 已保存');
        }
      } catch (e) {}
      if (!okMsg) { // 兜底：浏览器下载
        const a = document.createElement('a'); a.href = url; a.download = name; a.click();
        okMsg = '✓ 已下载（在浏览器下载目录）';
      }
      sb.textContent = okMsg || '已取消';
      if (!okMsg) setTimeout(() => sb.textContent = '💾 保存图片', 1500);
    };
  }

  /* ---------- 授权码获取教程（2026-11-04）：QQ邮箱官方路径（2025年6月新版界面） ---------- */
  function showCodeGuide() {
    let m = $('tgxCodeGuideMask');
    if (m) { m.style.display = 'flex'; return; }
    m = document.createElement('div');
    m.id = 'tgxCodeGuideMask';
    m.style.cssText = 'position:fixed;inset:0;background:rgba(40,20,35,.45);z-index:999999;display:flex;align-items:center;justify-content:center';
    m.innerHTML = `
      <div style="background:#fff;border-radius:16px;max-width:520px;width:92%;max-height:82vh;overflow-y:auto;padding:22px 24px;box-shadow:0 18px 60px rgba(0,0,0,.25);font-size:14px;line-height:1.7;color:#333">
        <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:10px">
          <b style="font-size:17px;color:#d63384">📖 授权码获取教程（以 QQ 邮箱为例）</b>
          <button id="tgxCodeGuideClose" style="border:0;background:none;font-size:20px;cursor:pointer;color:#999">✕</button>
        </div>
        <p style="margin:0 0 8px;padding:8px 12px;background:#fff0f4;border-radius:8px"><b style="color:#d63384">⚠️ 授权码不是邮箱密码！</b>是邮箱官方发给第三方软件专用的 16 位密码，要去邮箱网页版自己生成。</p>
        <ol style="margin:6px 0 10px;padding-left:22px">
          <li>电脑浏览器打开 <b>mail.qq.com</b> 并登录（手机 App 上生成不了）</li>
          <li>点右上角 <b>设置</b> → <b>账号与安全</b> → <b>安全管理</b></li>
          <li>找到 <b>POP3/IMAP/SMTP服务</b> → 点 <b>开启服务</b>（没开过要先开）</li>
          <li>点 <b>生成授权码</b> → 按提示验证（输 QQ 密码或手机 QQ 扫码）</li>
          <li>弹出 <b style="color:#d63384">16 位授权码</b> → <b>立即复制保存</b>（页面关了就再也看不到）</li>
          <li>回到本软件：<b>授权码</b>框粘贴它 → 点 <b>测试</b> 验证连通</li>
        </ol>
        <p style="margin:0 0 6px;padding:8px 12px;background:#f6f8fa;border-radius:8px;font-size:13px">📮 表单这么填：<b>SMTP服务器</b> smtp.qq.com · <b>邮箱账号</b> 完整邮箱（如 123456@qq.com）· <b>授权码</b> 刚生成的 16 位 · 勾 <b>SSL</b></p>
        <p style="margin:0;font-size:13px;color:#666">用 163 邮箱也一样：mail.163.com → 设置 → POP3/SMTP/IMAP → 开启服务 → 生成授权码。改过邮箱密码的话旧授权码会失效，重新生成一个就行。</p>
      </div>`;
    document.body.appendChild(m);
    m.addEventListener('click', e => { if (e.target === m) m.style.display = 'none'; });
    m.querySelector('#tgxCodeGuideClose').addEventListener('click', () => { m.style.display = 'none'; });
  }

  /* ---------- 注入 ---------- */
  function inject() {
    // 0) 子页感知：日志与发送设置卡只在「新建投稿」页出现
    const vt = document.getElementById('viewTougao');
    if (vt) {
      const on = vt.querySelector('.page.on');
      vt.classList.toggle('tg-nosend', !(on && on.id === 'p-send'));
    }

    // 1) 新建投稿页：不注入任何东西——包包要求恢复旧版界面（2026-11-01）

    // 2) 编辑库页：体检按钮
    const edCount = $('edCount');
    if (edCount && !$('tgxHealthBtn')) {
      const b = document.createElement('button');
      b.className = 'btn'; b.id = 'tgxHealthBtn'; b.textContent = '🩺 体检报告';
      b.style.marginLeft = '8px';
      b.addEventListener('click', healthReport);
      const addEdBtn = document.querySelector('#btnAddEd');
      (addEdBtn ? addEdBtn.parentNode : (edCount.closest('h3') || edCount.parentNode)).appendChild(b);
    }
    // 3) 投稿记录页：失败诊断按钮（打开体检报告聚焦发送体检）
    const rcTotal = $('rcTotal');
    if (rcTotal && !$('tgxDiagBtn')) {
      const b = document.createElement('button');
      b.className = 'btn'; b.id = 'tgxDiagBtn'; b.textContent = '🔍 失败原因诊断';
      b.style.marginLeft = '8px';
      b.addEventListener('click', healthReport);
      (rcTotal.parentNode).appendChild(b);
    }
    // 4) 新建投稿页：投稿打卡按钮（2026-11-02 包包拍板：从投稿记录页挪到「开始群发」旁边）
    const sendBtn = $('btnSend');
    if (sendBtn && !$('tgxPunchBtn')) {
      const b = document.createElement('button');
      b.className = 'btn pink'; b.id = 'tgxPunchBtn'; b.textContent = '📸 投稿打卡';
      b.style.marginLeft = '8px';
      b.addEventListener('click', punchCard);
      sendBtn.insertAdjacentElement('afterend', b);
    }

    // 4b) 邮箱设置区：授权码获取教程按钮（2026-11-04 包包要求：学员不会找授权码）
    const addAcc = $('btnAddAcc');
    if (addAcc && !$('tgxCodeGuideBtn')) {
      const b = document.createElement('button');
      b.className = 'btn'; b.id = 'tgxCodeGuideBtn'; b.textContent = '📖 授权码怎么获取？';
      b.style.marginLeft = '8px';
      b.addEventListener('click', showCodeGuide);
      addAcc.insertAdjacentElement('afterend', b);
    }
    // 授权码输入框：悬停提示
    document.querySelectorAll('#accList input[data-k="pass"]').forEach(inp => {
      if (inp._tgxTip) return; inp._tgxTip = true;
      inp.title = '不是邮箱密码！点「授权码怎么获取？」按钮查看生成步骤';
    });

    // 5) 投稿日志：不再加「清空/收起」按钮（2026-11-02 用户拍板删掉，日志保持展开、只增不清）
    // 6) 日志追加后自动滚到最新一条
    const logEl = $('tgLog');
    if (logEl && !logEl._tgxAutoScroll) {
      logEl._tgxAutoScroll = true;
      new MutationObserver(() => { logEl.scrollTop = logEl.scrollHeight; }).observe(logEl, { childList: true, subtree: true });
    }
  }
  let tries = 0;
  const iv = setInterval(() => { inject(); if (++tries > 90) clearInterval(iv); }, 1000);
  const mo = new MutationObserver(() => { clearTimeout(mo._t); mo._t = setTimeout(inject, 500); });
  mo.observe(document.documentElement, { childList: true, subtree: true });

  /* ---------- SMTP 服务器防呆（2026-11-04：学员把邮箱填进 SMTP服务器框导致 ENOTFOUND） ----------
     规则：host 框填了含 @ 的邮箱、或不含 smtp. 的值时，按域名映射自动纠正为正确的 SMTP 服务器 */
  (function () {
    const MAP = {
      'qq.com': 'smtp.qq.com', 'foxmail.com': 'smtp.qq.com', '163.com': 'smtp.163.com',
      '126.com': 'smtp.126.com', 'yeah.net': 'smtp.yeah.net', 'sina.com': 'smtp.sina.com',
      'sina.cn': 'smtp.sina.com', 'aliyun.com': 'smtp.aliyun.com', 'gmail.com': 'smtp.gmail.com',
      'outlook.com': 'smtp.office365.com', 'hotmail.com': 'smtp.office365.com'
    };
    function fixHost(inp) {
      let v = (inp.value || '').trim();
      if (!v || /^smtp\./i.test(v)) return;
      let dom = v.replace(/.*@/i, '').toLowerCase();          // 填了邮箱 → 取域名
      const tail = dom.split('.').slice(-2).join('.');         // 761431427.qq.com → qq.com
      const right = MAP[tail];
      if (right) {
        inp.value = right;
        inp.style.outline = '2px solid #35b36a';
        setTimeout(() => { inp.style.outline = ''; }, 1800);
        try { if (window.baobaoToast) window.baobaoToast('📧 SMTP服务器已自动纠正为 ' + right + '（你原来填的「' + v.slice(0, 30) + '」不是服务器地址）。授权码去邮箱设置里生成哦～'); } catch (e) {}
      }
    }
    document.addEventListener('change', e => {
      const t = e.target;
      if (t && t.matches && t.matches('input[data-k="host"]')) fixHost(t);
    }, true);
    // 定时兜底扫描（防止 change 没触发：填完直接点测试）
    setInterval(() => {
      document.querySelectorAll('#accList input[data-k="host"]').forEach(fixHost);
    }, 2000);
  })();
})();
