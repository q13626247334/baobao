/* 包包投稿扩展 · 主进程外挂模块（明文，不参与混淆）
 * 由 tougao.cjs 末尾 require 并在原 setup 完成后调用 setup()。
 * 提供作品档案 / 附件注入 / 编辑库体检 / 退信归类 接口（tg:ext:*）。
 * 所有逻辑独立，失败不影响原有投稿功能。
 */
'use strict';
const path = require('path');
const fs = require('fs');

function setup() {
  const { app, ipcMain, dialog } = require('electron');
  const DP = path.join(app.getPath('userData'), 'tougao-data');
  if (!fs.existsSync(DP)) fs.mkdirSync(DP, { recursive: true });
  const PROF_F = path.join(DP, 'profile.json');
  const readJ = (f, dft) => { try { return JSON.parse(fs.readFileSync(f, 'utf8')); } catch (e) { return dft; } };
  const saveJ = (f, d) => { const t = f + '.tmp'; fs.writeFileSync(t, JSON.stringify(d, null, 1)); try { fs.renameSync(t, f); } catch (e) { fs.writeFileSync(f, JSON.stringify(d, null, 1)); } };
  const PROF_DFT = {
    bookName: '', penName: '', genre: '', wordCount: '', status: '连载中',
    intro: '', selling: '', outline: '',
    attachMode: 'none', attachPath: '', attachName: '', contact: ''
  };
  const profGet = () => Object.assign({}, PROF_DFT, readJ(PROF_F, {}));

  const reg = (ch, fn) => { try { if (!ipcMain._handlers || !ipcMain._handlers[ch]) ipcMain.handle(ch, fn); } catch (e) { console.error('tgext-reg', ch, e); } };

  /* ---- 作品档案 ---- */
  reg('tg:ext:profile:get', () => ({ ok: 1, profile: profGet() }));
  reg('tg:ext:profile:save', (e, p) => {
    const cur = profGet();
    const inc = p && p.profile ? p.profile : {};
    for (const k of Object.keys(PROF_DFT)) if (typeof inc[k] === 'string') cur[k] = inc[k].slice(0, 8000);
    saveJ(PROF_F, cur);
    return { ok: 1 };
  });
  reg('tg:ext:pickAttach', async () => {
    const r = await dialog.showOpenDialog({ title: '选择要作为附件的作品文件', filters: [{ name: '文档', extensions: ['docx', 'doc', 'txt', 'pdf'] }], properties: ['openFile'] });
    if (r.canceled || !r.filePaths.length) return { ok: 0 };
    const f = r.filePaths[0];
    return { ok: 1, path: f, name: path.basename(f) };
  });

  /* ---- 编辑库体检报告 ---- */
  const daysAgo = d => { const t = new Date(d + 'T00:00:00'); return isFinite(t) ? Math.floor((Date.now() - t) / 86400000) : 9999; };
  reg('tg:ext:report', () => {
    const ed = readJ(path.join(DP, 'editors.json'), { list: [] });
    const list = ed.list || [];
    const by = k => { const m = {}; list.forEach(x => { const v = String(x[k] || '未填'); m[v] = (m[v] || 0) + 1; }); return m; };
    const noMail = list.filter(x => !String(x.email || '').trim()).map(x => x.org + '/' + x.name);
    const dup = {}; const dupList = [];
    list.forEach(x => { const k = String(x.email || '').toLowerCase().trim(); if (!k) return; (dup[k] = dup[k] || []).push(x); });
    Object.values(dup).filter(a => a.length > 1).forEach(a => dupList.push(a[0].email + '（' + a.map(x => x.name).join('、') + '）'));
    const stale = list.filter(x => x.status === '当前' && daysAgo(String(x.acceptAt || '').slice(0, 10)) > 90).map(x => x.org + '/' + x.name + '（' + String(x.acceptAt || '').slice(0, 10) + '未复核）');
    const confirmFirst = list.filter(x => x.status === '投前确认');
    const dead = list.filter(x => x.status === '历史' || x.status === '已离职');
    const check = list.filter(x => x.status === '待核实' || x.status === '待复核');
    // 投稿记录与失败归类
    const letters = readJ(path.join(DP, 'letters.json'), []);
    const sent = Array.isArray(letters) ? letters : (letters.list || []);
    let fail = 0, ok = 0;
    const bounce = { '邮箱不存在/地址错误': 0, '收件箱已满': 0, '被对方拒收/拉黑': 0, '疑似判为垃圾邮件': 0, '网络或服务器波动': 0, '其他失败': 0 };
    const bounceSamples = {};
    const classify = t => {
      t = String(t || '');
      if (/550|5\.1\.1|user not found|不存在|unknown user|no such user/i.test(t)) return '邮箱不存在/地址错误';
      if (/552|quota|over.?quota|mailbox full|容量/i.test(t)) return '收件箱已满';
      if (/551|553|554|5\.7\.|denied|refused|black.?list|spam|拒收|拉黑|拦截/i.test(t)) return '被对方拒收/拉黑';
      if (/垃圾|垃圾箱|junk|bulk|DMARC|SPF|DKIM/i.test(t)) return '疑似判为垃圾邮件';
      if (/timeout|ECONN|ENOTFOUND|DNS|超时|网络|421|450/i.test(t)) return '网络或服务器波动';
      return '其他失败';
    };
    sent.forEach(x => {
      const err = x.error || x.err || '';
      if (x.ok) { ok++; return; }
      if (!err) return;
      fail++;
      const c = classify(err);
      bounce[c]++;
      if (!bounceSamples[c]) bounceSamples[c] = String(err).slice(0, 120);
    });
    const tips = [];
    if (confirmFirst.length) tips.push('有 ' + confirmFirst.length + ' 位编辑标记为「投前确认」，投之前先在编辑库确认他们还在收稿。');
    if (check.length) tips.push('有 ' + check.length + ' 位编辑「待核实」，建议每月抽 10 分钟用软件内的过稿检测或搜索引擎核一遍。');
    if (noMail.length) tips.push('有 ' + noMail.length + ' 位编辑没有邮箱，投稿时会被自动跳过：' + noMail.slice(0, 5).join('、') + (noMail.length > 5 ? ' 等' : ''));
    if (dupList.length) tips.push('发现 ' + dupList.length + ' 个重复邮箱（同一邮箱录了多位编辑，浪费发送次数）：' + dupList.slice(0, 5).join('；'));
    if (stale.length) tips.push('有 ' + stale.length + ' 位「当前」编辑超过 90 天没复核过，收稿方向可能已变：' + stale.slice(0, 5).join('、') + (stale.length > 5 ? ' 等' : ''));
    if (bounce['邮箱不存在/地址错误'] > 0) tips.push('有 ' + bounce['邮箱不存在/地址错误'] + ' 次发送失败是「邮箱不存在」，建议把这些编辑降级为「历史」，别再投。');
    if (bounce['疑似判为垃圾邮件'] > 0) tips.push('有 ' + bounce['疑似判为垃圾邮件'] + ' 次疑似被判垃圾邮件：开启「每封随机问候」、拉长发件间隔、减少单邮箱当日发送量。');
    if (!tips.length) tips.push('编辑库状态健康，暂无需要处理的问题。');
    return {
      ok: 1,
      total: list.length,
      status: by('status'),
      accept: by('accept'),
      noMail, dupList, stale: stale.slice(0, 20),
      counts: { confirmFirst: confirmFirst.length, dead: dead.length, check: check.length },
      sent: { ok, fail, bounce, bounceSamples },
      tips,
      updatedAt: ed.updated || ''
    };
  });

  /* ---- 群发前预览数据：读当前已选编辑（从渲染层传） + 附件模式提示 ---- */
  reg('tg:ext:preview', (e, p) => {
    const prof = profGet();
    const attachReady = prof.attachMode === 'file' && prof.attachPath && fs.existsSync(prof.attachPath);
    return { ok: 1, attachReady, attachMode: prof.attachMode, attachName: prof.attachName, penName: prof.penName || '', bookName: prof.bookName || '', contact: prof.contact || '' };
  });

  /* ---- 投稿打卡：聚合当天/近7天的投稿数据，给渲染层画打卡卡 ---- */
  const dayKey = t => { const n = typeof t === 'number' ? t : (/^\d{10,14}$/.test(String(t)) ? Number(t) : t); const d = new Date(n); return isFinite(d) ? d.toISOString().slice(0, 10) : ''; };
  const firstOf = (o, keys) => { for (const k of keys) { const v = o && o[k]; if (v !== undefined && v !== null && String(v).trim() !== '') return String(v).trim(); } return ''; };
  /* ---- 最近投稿动态：给工作台显示最近几封投稿（2026-11-02） ---- */
  reg('tg:ext:recent', () => {
    const readArr = (f) => { const d = readJ(path.join(DP, f), []); return Array.isArray(d) ? d : (d && Array.isArray(d.list) ? d.list : []); };
    const letters = readArr('letters.json');
    const ts = v => { if (typeof v === 'number') return v; const n = Date.parse(String(v).replace(' ', 'T')); return isFinite(n) ? n : (Number(v) || 0); };
    const list = letters.map(l => ({
      at: firstOf(l, ['at', 'time', 'ts', 'date', 'sentAt', 'createdAt']),
      org: firstOf(l, ['org', 'platform', 'to']),
      name: firstOf(l, ['name', 'editor', 'editorName']),
      doc: firstOf(l, ['doc', 'docName', 'fileName', 'file', 'book', 'bookName']),
      okv: !!l.ok,
      err: firstOf(l, ['error', 'err', 'fail', 'reason'])
    })).sort((a, b) => ts(b.at) - ts(a.at)).slice(0, 8);
    return { ok: 1, list };
  });

  reg('tg:ext:punch', () => {
    const readArr = (f) => { const d = readJ(path.join(DP, f), []); return Array.isArray(d) ? d : (d && Array.isArray(d.list) ? d.list : []); };
    const submissions = readArr('submissions.json');
    const letters = readArr('letters.json');
    const editors = (() => { const d = readJ(path.join(DP, 'editors.json'), { list: [] }); return d.list || []; })();
    // 按天聚合：一份作品全平台投完 = 一条 submission（也可能只有 letters 明细）
    const byDay = {}; // day -> { mails, orgs:Set, docs:Set }
    const bump = (day, f) => {
      if (!day) return;
      const d = byDay[day] || (byDay[day] = { mails: 0, orgs: {}, docs: {} });
      d.mails += f.mails || 0;
      (f.orgs || []).forEach(o => d.orgs[o] = 1);
      (f.docs || []).forEach(o => d.docs[o] = 1);
    };
    submissions.forEach(s => {
      const doc = firstOf(s, ['doc', 'docName', 'fileName', 'file', 'book', 'bookName', 'title', 'name']);
      const day = dayKey(firstOf(s, ['at', 'time', 'ts', 'date', 'firstAt', 'createdAt', 'when', 'startAt']) || Date.now());
      const cnt = Number(s.count || s.mails || s.sent || 0) || 0;
      const orgs = Array.isArray(s.orgs) ? s.orgs.map(String) : (s.org ? [String(s.org)] : []);
      bump(day, { mails: cnt || (orgs.length || 1), orgs, docs: doc ? [doc] : [] });
    });
    letters.forEach(l => {
      const day = dayKey(firstOf(l, ['at', 'time', 'ts', 'date', 'sentAt', 'createdAt']) || Date.now());
      const org = firstOf(l, ['org', 'platform', 'to']) || firstOf(l, ['name']);
      const doc = firstOf(l, ['doc', 'docName', 'fileName', 'file', 'book', 'bookName']);
      bump(day, { mails: 1, orgs: org ? [org] : [], docs: doc ? [doc] : [] });
    });
    const days = Object.keys(byDay).sort().slice(-14);
    const today = dayKey(Date.now());
    const t = byDay[today] || { mails: 0, orgs: {}, docs: {} };
    // 连续打卡天数（从今天或昨天往前数，都有邮件的天才算）
    let streak = 0; const cur = new Date();
    if (!byDay[dayKey(cur)]) cur.setDate(cur.getDate() - 1); // 今天还没投，从昨天数
    while (byDay[dayKey(cur)]) { streak++; cur.setDate(cur.getDate() - 1); }
    // 近7天趋势
    const trend = [];
    for (let i = 6; i >= 0; i--) { const d = new Date(); d.setDate(d.getDate() - i); const k = dayKey(d); trend.push({ day: k.slice(5), mails: (byDay[k] || {}).mails || 0 }); }
    const todayOrgs = Object.keys(t.orgs);
    const todayDocs = Object.keys(t.docs);
    return {
      ok: 1,
      today: { mails: t.mails, orgs: todayOrgs, orgCount: todayOrgs.length, docs: todayDocs, docCount: todayDocs.length },
      streak,
      trend,
      totalMails: Object.values(byDay).reduce((a, d) => a + d.mails, 0),
      activeDays: days.filter(k => (byDay[k].mails || 0) > 0).length,
      editors: editors.length,
      penName: profGet().penName || '',
      day: today
    };
  });

  /* ---- 附件注入：包装原有 tg:send:start ---- */
  // 2026-11-01 包包拍板：作品档案界面已撤下，群发不再自动带附件（保持旧版行为：只发正文）。
  // 原逻辑：profile.attachMode==='file' 时给 job 自动补 attachPath。留档不启用。
  try {
    if (ipcMain._handlers && typeof ipcMain._handlers.get === 'function') {
      const orig = ipcMain._handlers.get('tg:send:start');
      if (orig) {
        ipcMain._handlers.set('tg:send:start', async (ev, job) => {
          return orig(ev, job);
        });
      }
    }
  } catch (e) { console.error('tgext-wrap-init', e); }
}

module.exports = { setup };
